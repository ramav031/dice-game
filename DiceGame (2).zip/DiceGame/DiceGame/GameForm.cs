﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace DiceGame
{
    public partial class GameForm : Form
    {
        public GameForm()
        {
            InitializeComponent();
        }

        private async void BtnRoll_Click(object sender, EventArgs e)
        {
            Form FormRoll = new Roll3_double(); // Form
            Form Win_Form = new WinForm();
            
            BtnRoll.Visible = false;

            Score.Rounds += 1;
            RoundText.Text = "Round: " + Score.Rounds.ToString();
            RoundText.Visible = true;


            Random roll = new Random();
            int Dice1 = roll.Next(1, 7);
            int Dice1_2 = roll.Next(1, 7);
            int Dice2 = roll.Next(1, 7);
            int Dice2_2 = roll.Next(1, 7);
            for (int i = 1; i < 50; i++)
            {
                await Task.Delay(i >= 90 ? i + i + i : 2 * i);
                int rand1 = roll.Next(1, 7);
                int rand2 = roll.Next(1, 7);
                int rand3 = roll.Next(1, 7);
                int rand4 = roll.Next(1, 7);
                Roll1.Text = rand1.ToString();
                Dice1_img.Image = Dice_Faces.Images[rand1 - 1];
                Dice1_2_img.Image = Dice_Faces.Images[rand2 - 1];
                Roll1_2.Text = rand2.ToString();
                await Task.Delay(1);
                Roll2.Text = rand3.ToString();
                Roll2_2.Text = rand4.ToString();
                Dice2_img.Image = Dice_Faces.Images[rand3 - 1];
                Dice2_2_img.Image = Dice_Faces.Images[rand4 - 1];

            }
            Thread.Sleep(500);
            
            Roll1.Text = Dice1.ToString();
            Roll1_2.Text = Dice1_2.ToString();
            Roll2.Text = Dice2.ToString();
            Roll2_2.Text = Dice2_2.ToString();
            Score.Player1Score += Dice1 + Dice1_2 + ((Dice1 + Dice1_2) % 2 == 0 ? 10 : -5);
            Score.Player1Score = Score.Player1Score < 0 ? 0: Score.Player1Score;
            Score.Player2Score += Dice2 + Dice2_2 + ((Dice2 + Dice2_2) % 2 == 0 ? 10 : -5);
            Score.Player2Score = Score.Player2Score < 0 ? 0 : Score.Player2Score;
            Score1.Text = Score.Player1Score.ToString();
            Score2.Text = Score.Player2Score.ToString();
            
            
            await Task.Delay(2000);
            if (Dice1 == Dice1_2) { Score.WhichPlayerDouble = 1; this.Dispose(); FormRoll.ShowDialog(); }
            if (Dice2 == Dice2_2 ) { Score.WhichPlayerDouble = 2; this.Dispose(); FormRoll.ShowDialog(); }
            BtnRoll.Visible = true;
           
            if (Score.Rounds == 5) { Win_Form.ShowDialog(); this.Close(); }
        }

        private void GameForm_Load(object sender, EventArgs e)
        {
            
            Form Win_Form = new WinForm();
            Score1.Text = Score.Player1Score.ToString();
            Score2.Text = Score.Player2Score.ToString();
            RoundText.Text = RoundText.Text = "Round: " + Score.Rounds.ToString();
            if (Score.Rounds == 5) { Win_Form.ShowDialog(); this.Close(); }
        }

        private void RoundText_Click(object sender, EventArgs e)
        {

        }
    }
}
