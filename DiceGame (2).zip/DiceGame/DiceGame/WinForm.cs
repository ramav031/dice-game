﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace DiceGame
{
    public partial class WinForm : Form
    {
        public WinForm()
        {
            InitializeComponent();
        }

        private void WinForm_Load(object sender, EventArgs e)
        {
             Form tiebreak = new Roll3tie();
           
            if (Score.Player1Score == Score.Player2Score) { tiebreak.ShowDialog(); this.Close(); }
            PlayerLabel.Text += " " + (Score.Player1Score > Score.Player2Score ? "1" : "2");
            Scoretxt.Text += (Score.Player1Score > Score.Player2Score ? Score.Player1Score.ToString() : Score.Player2Score.ToString());
        }

        private void Scoretxt_TextChanged(object sender, EventArgs e)
        {

        }
    }
}
