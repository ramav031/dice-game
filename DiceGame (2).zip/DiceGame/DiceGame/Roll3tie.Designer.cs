﻿namespace DiceGame
{
    partial class Roll3tie
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.tielb = new System.Windows.Forms.Label();
            this.BtnRoll = new System.Windows.Forms.Button();
            this.Roll2 = new System.Windows.Forms.TextBox();
            this.Roll1 = new System.Windows.Forms.TextBox();
            this.Player1lb = new System.Windows.Forms.Label();
            this.Player2lb = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // tielb
            // 
            this.tielb.AutoSize = true;
            this.tielb.Font = new System.Drawing.Font("SketchFlow Print", 26.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tielb.Location = new System.Drawing.Point(526, 206);
            this.tielb.Name = "tielb";
            this.tielb.Size = new System.Drawing.Size(255, 37);
            this.tielb.TabIndex = 16;
            this.tielb.Text = "Tie Breaker!";
            // 
            // BtnRoll
            // 
            this.BtnRoll.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.BtnRoll.FlatStyle = System.Windows.Forms.FlatStyle.System;
            this.BtnRoll.Font = new System.Drawing.Font("Segoe Print", 26.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.BtnRoll.Location = new System.Drawing.Point(554, 100);
            this.BtnRoll.Name = "BtnRoll";
            this.BtnRoll.Size = new System.Drawing.Size(181, 91);
            this.BtnRoll.TabIndex = 11;
            this.BtnRoll.Text = "ROLL";
            this.BtnRoll.UseVisualStyleBackColor = true;
            this.BtnRoll.Click += new System.EventHandler(this.BtnRoll_Click);
            // 
            // Roll2
            // 
            this.Roll2.AccessibleRole = System.Windows.Forms.AccessibleRole.None;
            this.Roll2.BackColor = System.Drawing.Color.White;
            this.Roll2.Font = new System.Drawing.Font("Segoe Print", 26.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Roll2.Location = new System.Drawing.Point(780, 80);
            this.Roll2.Name = "Roll2";
            this.Roll2.ReadOnly = true;
            this.Roll2.Size = new System.Drawing.Size(150, 69);
            this.Roll2.TabIndex = 10;
            // 
            // Roll1
            // 
            this.Roll1.BackColor = System.Drawing.Color.White;
            this.Roll1.Font = new System.Drawing.Font("Segoe Print", 26.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Roll1.Location = new System.Drawing.Point(363, 80);
            this.Roll1.Name = "Roll1";
            this.Roll1.ReadOnly = true;
            this.Roll1.Size = new System.Drawing.Size(150, 69);
            this.Roll1.TabIndex = 9;
            // 
            // Player1lb
            // 
            this.Player1lb.AutoSize = true;
            this.Player1lb.Font = new System.Drawing.Font("SketchFlow Print", 26.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Player1lb.Location = new System.Drawing.Point(358, 282);
            this.Player1lb.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.Player1lb.Name = "Player1lb";
            this.Player1lb.Size = new System.Drawing.Size(146, 37);
            this.Player1lb.TabIndex = 17;
            this.Player1lb.Text = "Player1";
            // 
            // Player2lb
            // 
            this.Player2lb.AutoSize = true;
            this.Player2lb.Font = new System.Drawing.Font("SketchFlow Print", 26.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Player2lb.Location = new System.Drawing.Point(784, 282);
            this.Player2lb.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.Player2lb.Name = "Player2lb";
            this.Player2lb.Size = new System.Drawing.Size(157, 37);
            this.Player2lb.TabIndex = 18;
            this.Player2lb.Text = "Player2";
            // 
            // Roll3tie
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.Aquamarine;
            this.ClientSize = new System.Drawing.Size(1292, 382);
            this.Controls.Add(this.Player2lb);
            this.Controls.Add(this.Player1lb);
            this.Controls.Add(this.tielb);
            this.Controls.Add(this.BtnRoll);
            this.Controls.Add(this.Roll2);
            this.Controls.Add(this.Roll1);
            this.Name = "Roll3tie";
            this.Text = "Roll3tie";
            this.Load += new System.EventHandler(this.Roll3tie_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label tielb;
        private System.Windows.Forms.Button BtnRoll;
        private System.Windows.Forms.TextBox Roll2;
        private System.Windows.Forms.TextBox Roll1;
        private System.Windows.Forms.Label Player1lb;
        private System.Windows.Forms.Label Player2lb;
    }
}