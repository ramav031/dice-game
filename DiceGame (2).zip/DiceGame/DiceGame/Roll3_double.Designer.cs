﻿namespace DiceGame
{
    partial class Roll3_double
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.BtnRoll = new System.Windows.Forms.Button();
            this.Roll3Double = new System.Windows.Forms.TextBox();
            this.PlayerLabel = new System.Windows.Forms.Label();
            this.DoubleText = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // BtnRoll
            // 
            this.BtnRoll.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.BtnRoll.FlatStyle = System.Windows.Forms.FlatStyle.System;
            this.BtnRoll.Font = new System.Drawing.Font("Segoe Print", 24F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.BtnRoll.Location = new System.Drawing.Point(56, 153);
            this.BtnRoll.Name = "BtnRoll";
            this.BtnRoll.Size = new System.Drawing.Size(164, 83);
            this.BtnRoll.TabIndex = 4;
            this.BtnRoll.Text = "ROLL";
            this.BtnRoll.UseVisualStyleBackColor = true;
            this.BtnRoll.Click += new System.EventHandler(this.BtnRoll_Click);
            // 
            // Roll3Double
            // 
            this.Roll3Double.AccessibleRole = System.Windows.Forms.AccessibleRole.None;
            this.Roll3Double.BackColor = System.Drawing.Color.White;
            this.Roll3Double.Font = new System.Drawing.Font("Segoe Print", 27.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Roll3Double.Location = new System.Drawing.Point(45, 64);
            this.Roll3Double.Name = "Roll3Double";
            this.Roll3Double.ReadOnly = true;
            this.Roll3Double.Size = new System.Drawing.Size(194, 73);
            this.Roll3Double.TabIndex = 5;
            // 
            // PlayerLabel
            // 
            this.PlayerLabel.AutoSize = true;
            this.PlayerLabel.Font = new System.Drawing.Font("SketchFlow Print", 27.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.PlayerLabel.Location = new System.Drawing.Point(64, 9);
            this.PlayerLabel.Name = "PlayerLabel";
            this.PlayerLabel.Size = new System.Drawing.Size(141, 40);
            this.PlayerLabel.TabIndex = 6;
            this.PlayerLabel.Text = "Player";
            // 
            // DoubleText
            // 
            this.DoubleText.AutoSize = true;
            this.DoubleText.Font = new System.Drawing.Font("SketchFlow Print", 36F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.DoubleText.Location = new System.Drawing.Point(24, 254);
            this.DoubleText.Name = "DoubleText";
            this.DoubleText.Size = new System.Drawing.Size(234, 51);
            this.DoubleText.TabIndex = 7;
            this.DoubleText.Text = "Doubles!";
            // 
            // Roll3_double
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.Aquamarine;
            this.ClientSize = new System.Drawing.Size(283, 354);
            this.Controls.Add(this.DoubleText);
            this.Controls.Add(this.PlayerLabel);
            this.Controls.Add(this.Roll3Double);
            this.Controls.Add(this.BtnRoll);
            this.Name = "Roll3_double";
            this.Text = "Roll3_double";
            this.Load += new System.EventHandler(this.Roll3_double_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button BtnRoll;
        private System.Windows.Forms.TextBox Roll3Double;
        private System.Windows.Forms.Label PlayerLabel;
        private System.Windows.Forms.Label DoubleText;
    }
}