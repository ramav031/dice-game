﻿namespace DiceGame
{
    partial class GameForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(GameForm));
            this.Roll1 = new System.Windows.Forms.TextBox();
            this.Roll2 = new System.Windows.Forms.TextBox();
            this.BtnRoll = new System.Windows.Forms.Button();
            this.Roll1_2 = new System.Windows.Forms.TextBox();
            this.Roll2_2 = new System.Windows.Forms.TextBox();
            this.Score1 = new System.Windows.Forms.TextBox();
            this.Score2 = new System.Windows.Forms.TextBox();
            this.RoundText = new System.Windows.Forms.Label();
            this.Dice1_img = new System.Windows.Forms.PictureBox();
            this.Dice2_img = new System.Windows.Forms.PictureBox();
            this.Dice1_2_img = new System.Windows.Forms.PictureBox();
            this.Dice2_2_img = new System.Windows.Forms.PictureBox();
            this.Dice_Faces = new System.Windows.Forms.ImageList(this.components);
            this.Player2lb = new System.Windows.Forms.Label();
            this.Player1lb = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.Dice1_img)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.Dice2_img)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.Dice1_2_img)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.Dice2_2_img)).BeginInit();
            this.SuspendLayout();
            // 
            // Roll1
            // 
            this.Roll1.BackColor = System.Drawing.Color.White;
            this.Roll1.Font = new System.Drawing.Font("Segoe Script", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Roll1.Location = new System.Drawing.Point(32, 114);
            this.Roll1.Name = "Roll1";
            this.Roll1.ReadOnly = true;
            this.Roll1.Size = new System.Drawing.Size(150, 46);
            this.Roll1.TabIndex = 1;
            // 
            // Roll2
            // 
            this.Roll2.AccessibleRole = System.Windows.Forms.AccessibleRole.None;
            this.Roll2.BackColor = System.Drawing.Color.White;
            this.Roll2.Font = new System.Drawing.Font("Segoe Print", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Roll2.Location = new System.Drawing.Point(451, 110);
            this.Roll2.Name = "Roll2";
            this.Roll2.ReadOnly = true;
            this.Roll2.Size = new System.Drawing.Size(150, 50);
            this.Roll2.TabIndex = 2;
            // 
            // BtnRoll
            // 
            this.BtnRoll.BackColor = System.Drawing.Color.Green;
            this.BtnRoll.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.BtnRoll.FlatStyle = System.Windows.Forms.FlatStyle.System;
            this.BtnRoll.Font = new System.Drawing.Font("Segoe Print", 26.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.BtnRoll.Location = new System.Drawing.Point(223, 110);
            this.BtnRoll.Name = "BtnRoll";
            this.BtnRoll.Size = new System.Drawing.Size(181, 91);
            this.BtnRoll.TabIndex = 3;
            this.BtnRoll.Text = "ROLL";
            this.BtnRoll.UseMnemonic = false;
            this.BtnRoll.UseVisualStyleBackColor = false;
            this.BtnRoll.Click += new System.EventHandler(this.BtnRoll_Click);
            // 
            // Roll1_2
            // 
            this.Roll1_2.AccessibleRole = System.Windows.Forms.AccessibleRole.None;
            this.Roll1_2.BackColor = System.Drawing.Color.White;
            this.Roll1_2.Font = new System.Drawing.Font("Segoe Script", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Roll1_2.Location = new System.Drawing.Point(32, 259);
            this.Roll1_2.Name = "Roll1_2";
            this.Roll1_2.ReadOnly = true;
            this.Roll1_2.Size = new System.Drawing.Size(150, 46);
            this.Roll1_2.TabIndex = 4;
            // 
            // Roll2_2
            // 
            this.Roll2_2.AccessibleRole = System.Windows.Forms.AccessibleRole.None;
            this.Roll2_2.BackColor = System.Drawing.Color.White;
            this.Roll2_2.Font = new System.Drawing.Font("Segoe Print", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Roll2_2.Location = new System.Drawing.Point(451, 255);
            this.Roll2_2.Name = "Roll2_2";
            this.Roll2_2.ReadOnly = true;
            this.Roll2_2.Size = new System.Drawing.Size(150, 50);
            this.Roll2_2.TabIndex = 5;
            // 
            // Score1
            // 
            this.Score1.AccessibleRole = System.Windows.Forms.AccessibleRole.None;
            this.Score1.BackColor = System.Drawing.Color.White;
            this.Score1.Font = new System.Drawing.Font("Segoe Script", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Score1.Location = new System.Drawing.Point(32, 363);
            this.Score1.Name = "Score1";
            this.Score1.ReadOnly = true;
            this.Score1.Size = new System.Drawing.Size(150, 46);
            this.Score1.TabIndex = 6;
            this.Score1.Text = "o";
            // 
            // Score2
            // 
            this.Score2.AccessibleRole = System.Windows.Forms.AccessibleRole.None;
            this.Score2.BackColor = System.Drawing.Color.White;
            this.Score2.Font = new System.Drawing.Font("Segoe Print", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Score2.Location = new System.Drawing.Point(451, 359);
            this.Score2.Name = "Score2";
            this.Score2.ReadOnly = true;
            this.Score2.Size = new System.Drawing.Size(150, 50);
            this.Score2.TabIndex = 7;
            // 
            // RoundText
            // 
            this.RoundText.AutoSize = true;
            this.RoundText.Font = new System.Drawing.Font("SketchFlow Print", 20.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.RoundText.Location = new System.Drawing.Point(242, 224);
            this.RoundText.Name = "RoundText";
            this.RoundText.Size = new System.Drawing.Size(158, 29);
            this.RoundText.TabIndex = 8;
            this.RoundText.Text = "Round - 0";
            this.RoundText.Visible = false;
            this.RoundText.Click += new System.EventHandler(this.RoundText_Click);
            // 
            // Dice1_img
            // 
            this.Dice1_img.Location = new System.Drawing.Point(67, 165);
            this.Dice1_img.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.Dice1_img.Name = "Dice1_img";
            this.Dice1_img.Size = new System.Drawing.Size(79, 84);
            this.Dice1_img.TabIndex = 9;
            this.Dice1_img.TabStop = false;
            // 
            // Dice2_img
            // 
            this.Dice2_img.Location = new System.Drawing.Point(67, 21);
            this.Dice2_img.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.Dice2_img.Name = "Dice2_img";
            this.Dice2_img.Size = new System.Drawing.Size(79, 84);
            this.Dice2_img.TabIndex = 10;
            this.Dice2_img.TabStop = false;
            // 
            // Dice1_2_img
            // 
            this.Dice1_2_img.Location = new System.Drawing.Point(485, 165);
            this.Dice1_2_img.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.Dice1_2_img.Name = "Dice1_2_img";
            this.Dice1_2_img.Size = new System.Drawing.Size(79, 84);
            this.Dice1_2_img.TabIndex = 11;
            this.Dice1_2_img.TabStop = false;
            // 
            // Dice2_2_img
            // 
            this.Dice2_2_img.Location = new System.Drawing.Point(485, 21);
            this.Dice2_2_img.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.Dice2_2_img.Name = "Dice2_2_img";
            this.Dice2_2_img.Size = new System.Drawing.Size(79, 84);
            this.Dice2_2_img.TabIndex = 12;
            this.Dice2_2_img.TabStop = false;
            // 
            // Dice_Faces
            // 
            this.Dice_Faces.ImageStream = ((System.Windows.Forms.ImageListStreamer)(resources.GetObject("Dice_Faces.ImageStream")));
            this.Dice_Faces.TransparentColor = System.Drawing.Color.Transparent;
            this.Dice_Faces.Images.SetKeyName(0, "DiceFace1.png");
            this.Dice_Faces.Images.SetKeyName(1, "DiceFace2.png");
            this.Dice_Faces.Images.SetKeyName(2, "DiceFace3.png");
            this.Dice_Faces.Images.SetKeyName(3, "DiceFace4.png");
            this.Dice_Faces.Images.SetKeyName(4, "DiceFace5.png");
            this.Dice_Faces.Images.SetKeyName(5, "DiceFace6.png");
            // 
            // Player2lb
            // 
            this.Player2lb.AutoSize = true;
            this.Player2lb.Font = new System.Drawing.Font("SketchFlow Print", 29.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Player2lb.Location = new System.Drawing.Point(444, 314);
            this.Player2lb.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.Player2lb.Name = "Player2lb";
            this.Player2lb.Size = new System.Drawing.Size(174, 42);
            this.Player2lb.TabIndex = 20;
            this.Player2lb.Text = "Player2";
            // 
            // Player1lb
            // 
            this.Player1lb.AutoSize = true;
            this.Player1lb.Font = new System.Drawing.Font("SketchFlow Print", 29.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Player1lb.Location = new System.Drawing.Point(25, 318);
            this.Player1lb.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.Player1lb.Name = "Player1lb";
            this.Player1lb.Size = new System.Drawing.Size(161, 42);
            this.Player1lb.TabIndex = 19;
            this.Player1lb.Text = "Player1";
            // 
            // GameForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.Aquamarine;
            this.ClientSize = new System.Drawing.Size(895, 414);
            this.Controls.Add(this.Player2lb);
            this.Controls.Add(this.Player1lb);
            this.Controls.Add(this.Dice2_2_img);
            this.Controls.Add(this.Dice1_2_img);
            this.Controls.Add(this.Dice2_img);
            this.Controls.Add(this.Dice1_img);
            this.Controls.Add(this.RoundText);
            this.Controls.Add(this.Score2);
            this.Controls.Add(this.Score1);
            this.Controls.Add(this.Roll2_2);
            this.Controls.Add(this.Roll1_2);
            this.Controls.Add(this.BtnRoll);
            this.Controls.Add(this.Roll2);
            this.Controls.Add(this.Roll1);
            this.Name = "GameForm";
            this.Text = "GameForm";
            this.Load += new System.EventHandler(this.GameForm_Load);
            ((System.ComponentModel.ISupportInitialize)(this.Dice1_img)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.Dice2_img)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.Dice1_2_img)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.Dice2_2_img)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox Roll1;
        private System.Windows.Forms.TextBox Roll2;
        private System.Windows.Forms.Button BtnRoll;
        private System.Windows.Forms.TextBox Roll1_2;
        private System.Windows.Forms.TextBox Roll2_2;
        private System.Windows.Forms.TextBox Score1;
        private System.Windows.Forms.TextBox Score2;
        private System.Windows.Forms.Label RoundText;
        private System.Windows.Forms.PictureBox Dice1_img;
        private System.Windows.Forms.PictureBox Dice2_img;
        private System.Windows.Forms.PictureBox Dice1_2_img;
        private System.Windows.Forms.PictureBox Dice2_2_img;
        private System.Windows.Forms.ImageList Dice_Faces;
        private System.Windows.Forms.Label Player2lb;
        private System.Windows.Forms.Label Player1lb;
    }
}