﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DiceGame
{
    class Score
    {
        private static double _Player1Score = 0;
        private static double _Player2Score = 0;
        private static double _WhichPlayerDouble = 0;
        private static double _Rounds = 0;
        
        public static double Player1Score
        {
            get { return _Player1Score; }
            set { _Player1Score = value; }
        }
        public static double Player2Score
        {
            get { return _Player2Score; }
            set { _Player2Score = value; }
        }
        public static double WhichPlayerDouble
        {
            get { return _WhichPlayerDouble; }
            set { _WhichPlayerDouble = value; }
        }
        public static double Rounds
        {
            get { return _Rounds; }
            set { _Rounds = value; }
        }
    }
}
