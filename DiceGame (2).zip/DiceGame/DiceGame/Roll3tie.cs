﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace DiceGame
{
    public partial class Roll3tie : Form
    {
        public Roll3tie()
        {
            InitializeComponent();
        }

        private async void BtnRoll_Click(object sender, EventArgs e)
        {
            BtnRoll.Visible = false;
            Random roll = new Random();
            int Dice1 = roll.Next(1, 7);
            
            int Dice2 = roll.Next(1, 7);
            
            for (int i = 1; i < 50; i++)
            {
                await Task.Delay(i >= 90 ? i + i + i : 2 * i);
                Roll1.Text = roll.Next(1, 7).ToString();
                
                await Task.Delay(1);
                Roll2.Text = roll.Next(1, 7).ToString();
               

            }
            Thread.Sleep(350);
            Roll1.Text = Dice1.ToString();
            Roll2.Text = Dice2.ToString();
            Score.Player1Score += Dice1;
            Score.Player2Score += Dice2;
            Thread.Sleep(350);
            Form Win_Form = new WinForm();
            Win_Form.ShowDialog(); 
            this.Close(); 
        }

        private void Roll3tie_Load(object sender, EventArgs e)
        {

        }
    }
}
