﻿namespace DiceGame
{
    partial class WinForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.PlayerLabel = new System.Windows.Forms.Label();
            this.Scoretxt = new System.Windows.Forms.TextBox();
            this.winlb = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // PlayerLabel
            // 
            this.PlayerLabel.AutoSize = true;
            this.PlayerLabel.Font = new System.Drawing.Font("SketchFlow Print", 72F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.PlayerLabel.Location = new System.Drawing.Point(190, 40);
            this.PlayerLabel.Name = "PlayerLabel";
            this.PlayerLabel.Size = new System.Drawing.Size(354, 101);
            this.PlayerLabel.TabIndex = 7;
            this.PlayerLabel.Text = "Player";
            // 
            // Scoretxt
            // 
            this.Scoretxt.AccessibleRole = System.Windows.Forms.AccessibleRole.None;
            this.Scoretxt.BackColor = System.Drawing.Color.White;
            this.Scoretxt.Font = new System.Drawing.Font("Segoe Print", 26.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Scoretxt.Location = new System.Drawing.Point(487, 168);
            this.Scoretxt.Name = "Scoretxt";
            this.Scoretxt.ReadOnly = true;
            this.Scoretxt.Size = new System.Drawing.Size(150, 69);
            this.Scoretxt.TabIndex = 8;
            this.Scoretxt.TextChanged += new System.EventHandler(this.Scoretxt_TextChanged);
            // 
            // winlb
            // 
            this.winlb.AutoSize = true;
            this.winlb.Font = new System.Drawing.Font("SketchFlow Print", 48F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.winlb.Location = new System.Drawing.Point(628, 257);
            this.winlb.Name = "winlb";
            this.winlb.Size = new System.Drawing.Size(237, 68);
            this.winlb.TabIndex = 9;
            this.winlb.Text = "Wins!!";
            // 
            // WinForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.Aquamarine;
            this.ClientSize = new System.Drawing.Size(1311, 371);
            this.Controls.Add(this.winlb);
            this.Controls.Add(this.Scoretxt);
            this.Controls.Add(this.PlayerLabel);
            this.Name = "WinForm";
            this.Text = "WinForm";
            this.Load += new System.EventHandler(this.WinForm_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label PlayerLabel;
        private System.Windows.Forms.TextBox Scoretxt;
        private System.Windows.Forms.Label winlb;
    }
}