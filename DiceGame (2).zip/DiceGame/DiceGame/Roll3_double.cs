﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Threading;
using System.Windows.Forms;

namespace DiceGame
{
    public partial class Roll3_double : Form
    {
        public Roll3_double()
        {
            InitializeComponent();
        }

        private async void BtnRoll_Click(object sender, EventArgs e)
        {
            BtnRoll.Visible = false;
            Random roll = new Random();
            int Dice3 = roll.Next(1, 7);
            for (int i = 1; i < 50; i++)
            {
                await Task.Delay(i >= 90 ? i + i + i : 2 * i);
                Roll3Double.Text = roll.Next(1, 7).ToString(); 
            }
            await Task.Delay(350);
            Roll3Double.Text = Dice3.ToString();
            if (Score.WhichPlayerDouble == 1) { Score.Player1Score += Dice3; }
            else{ Score.Player2Score += Dice3; }
            Score.WhichPlayerDouble = 0;
            await Task.Delay(2000);
            Form gameform = new GameForm();
            this.Dispose();
            gameform.ShowDialog();
            
        }

        private void Roll3_double_Load(object sender, EventArgs e)
        {
            PlayerLabel.Text = Score.WhichPlayerDouble == 1 ? "Player 1" : "Player 2";
            BtnRoll.Visible = true;
        }
    }
}
